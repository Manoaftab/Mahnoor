const Feedback = require('../models/Feedback');

// Submit Feedback
exports.submitFeedback = async (req, res) => {
  const { rating } = req.body;

  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ message: 'Rating must be between 1 and 5 stars.' });
  }

  try {
    const feedback = new Feedback({
      user: req.user._id, // User from authMiddleware
      rating,
    });

    const savedFeedback = await feedback.save();
    res.status(201).json(savedFeedback);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get All Feedback
exports.getFeedback = async (req, res) => {
  try {
    const feedbacks = await Feedback.find()
      .populate('user', 'name email') // Include user details
      .sort({ createdAt: -1 }); // Sort by latest feedback

    res.json(feedbacks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
