const path = require('path');
const fs = require('fs');

// Upload a file
exports.uploadFile = (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded!' });
    }

    res.status(201).json({
      message: 'File uploaded successfully!',
      filePath: `/uploads/${req.file.filename}`,
    });
  } catch (error) {
    res.status(500).json({ message: 'File upload failed', error: error.message });
  }
};

// Retrieve all uploaded files
exports.getUploadedFiles = (req, res) => {
  const directoryPath = path.join(__dirname, '../uploads');

  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      return res.status(500).json({ message: 'Unable to retrieve files', error: err.message });
    }

    const fileList = files.map((file) => ({
      name: file,
      url: `/uploads/${file}`,
    }));

    res.status(200).json(fileList);
  });
};
