const express = require('express');
const upload = require('../middlewares/uploadMiddleware');
const { uploadFile, getUploadedFiles } = require('../controllers/fileController');

const router = express.Router();

router.post('/upload', upload.single('file'), uploadFile); // Upload a single file
router.get('/files', getUploadedFiles); // Retrieve all uploaded files

module.exports = router;
