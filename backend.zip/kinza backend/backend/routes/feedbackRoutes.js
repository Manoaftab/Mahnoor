const express = require('express');
const { submitFeedback, getFeedback } = require('../controllers/feedbackController');
const { protect } = require('../middlewares/authMiddleware');

const router = express.Router();

router.post('/', protect, submitFeedback); // Submit Feedback
router.get('/', protect, getFeedback); // Get All Feedback

module.exports = router;
